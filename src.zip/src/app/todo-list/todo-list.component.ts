import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  public list = [{'item':'Tea Making', 'isSelected':false}, {'item':'Bill Payment', 'isSelected':false}, {'item':'Books shopping', 'isSelected':false}];

  public addNew(value) {
    this.list.push({'item':value, 'isSelected': false});
  }

  public remove(value, index) {
    if(this.list[index].isSelected) {
      this.list = this.list.filter(item => !item.isSelected)
    }
    
    
  }

  public isCheck(event, value) {
    console.log('calling -->' + event + ' value ' + this.list.indexOf(value))
    var indx = this.list.indexOf(value);
    if(event) {
      this.list[indx].isSelected = true
    } else {
      this.list[indx].isSelected = false
    }
    console.log(this.list)
    
  }

}
